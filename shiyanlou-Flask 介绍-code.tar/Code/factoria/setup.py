#!/usr/bin/env python3
from setuptools import find_packages, setup

setup(name='factorial_hifuer',
    version='0.1',
    description="Factorial module.",
    long_description="A test module for our book.",
    platforms=["Linux"],
    author="hifuer",
    author_email="hifuer@qq.com",
    url="https://www.shiyanlou.com/users/6856",
    license="MIT",
    packages=find_packages()
    )

